
-- Create database
CREATE DATABASE library_db;
USE library_db;

-- Create tables
CREATE TABLE Admin (
    admin_id INT PRIMARY KEY,
    username VARCHAR(100)
);

CREATE TABLE Member (
    member_id INT PRIMARY KEY,
    name VARCHAR(100),
    membership_date DATE
);

CREATE TABLE Book (
    book_id INT PRIMARY KEY,
    title VARCHAR(200),
    author VARCHAR(100),
    admin_id INT,
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id)
);

CREATE TABLE Borrowing (
    borrow_id INT PRIMARY KEY,
    book_id INT,
    member_id INT,
    borrow_date DATE,
    return_date DATE,
    FOREIGN KEY (book_id) REFERENCES Book(book_id),
    FOREIGN KEY (member_id) REFERENCES Member(member_id)
);

-- Insert data
INSERT INTO Admin VALUES 
(1, 'admin_ahmed'),
(2, 'admin_sara');

INSERT INTO Member VALUES
(1, 'Ali', '2023-01-01'),
(2, 'Sara', '2023-03-15'),
(3, 'Omar', '2023-05-20'),
(4, 'Laila', '2023-06-10'),
(5, 'Noor', '2023-07-25');

INSERT INTO Book VALUES
(1, 'Database Systems', 'Navathe', 1),
(2, 'Clean Code', 'Robert Martin', 1),
(3, 'Learning SQL', 'Alan Beaulieu', 2),
(4, 'Python Crash Course', 'Eric Matthes', 2),
(5, 'Artificial Intelligence', 'Stuart Russell', 1);

INSERT INTO Borrowing VALUES
(1, 1, 1, '2024-01-10', '2024-01-20'),
(2, 2, 2, '2024-01-12', '2024-01-22'),
(3, 3, 3, '2024-02-01', '2024-02-11'),
(4, 1, 4, '2024-02-15', '2024-02-25'),
(5, 5, 5, '2024-03-05', '2024-03-15');

-- Sample Queries
SELECT * FROM Book;

SELECT b.title
FROM Book b
JOIN Borrowing br ON b.book_id = br.book_id
JOIN Member m ON br.member_id = m.member_id
WHERE m.name = 'Ali';

SELECT m.name, COUNT(*) AS total_borrowed
FROM Borrowing br
JOIN Member m ON br.member_id = m.member_id
GROUP BY m.name;

SELECT b.title, m.name, br.return_date
FROM Borrowing br
JOIN Book b ON br.book_id = b.book_id
JOIN Member m ON br.member_id = m.member_id
WHERE br.return_date < '2024-04-01';

SELECT m.name
FROM Borrowing br
JOIN Member m ON br.member_id = m.member_id
GROUP BY m.name
HAVING COUNT(*) > 1;
